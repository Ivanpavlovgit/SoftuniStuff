

import java.util.ArrayList;

public class demoWorkShop {
    public static void main (String[] args) {
//        SmartArray smart = new SmartArray ();
////        long start=System.currentTimeMillis ();
////
////        for (int i = 0; i <1000000; i++) {
////            smart.add (i);
////        }
////        for (int i = 0; i <1000000; i++) {
////         smart.get (i);
////        }
////
//////        ArrayList<Integer> list = new ArrayList<> ();
//////        for (int i = 0; i < 1000000; i++) {
//////            list.add (i);
//////        }
////        long end=System.currentTimeMillis ();
////        System.out.println (end-start);
//        for (int i = 0; i <10000; i++) {
//            smart.add (i);
//        }
//        for (int i = 0; i <9999 ; i++) {
//            smart.remove (i);
//        }
//
//        smart.forEach (System.out::println);
//        System.out.println ();
        StackA stack = new StackA ();
        for (int i = 0; i < 12; i++) {
            stack.push (i + 1);
        }

       stack.forEach (System.out::println);
        System.out.println ();
    }
}
