import java.util.function.Consumer;

public class SmartArray {
    private static final int INITIAL_CAPACITY = 4;

    private int[] elements;
    private int size;

    public SmartArray () {
        this.elements = new int[INITIAL_CAPACITY];
        this.size = 0;
    }

    public void add (int element) {
        if (this.size == this.elements.length) {
            this.elements = grow ();
        }
        this.elements[this.size] = element;
        this.size++;
    }

    public int remove (int index) {
        validateIndex (index);
        int element = this.elements[index];
//        if (this.size - 1 - index >= 0) {
//            System.arraycopy (this.elements,index + 1,this.elements,index,this.size - 1 - index);
//        }
        for (int i = index; i <this.size-1 ; i++) {
            this.elements[i]=this.elements[i+1];
        }
        this.elements[this.size - 1] = 0;
        this.size--;
        if(this.elements.length>4&& this.size==this.elements.length/2){
            this.elements=shrink();
        }
        return element;
    }

    private int[] shrink () {
        int[] newElements = new int[this.elements.length / 2];
//        for (int i = 0; i < this.element.length; i++) {
//            newElements[i] = this.element[i];
//        }
        System.arraycopy (this.elements,0,newElements,0,newElements.length);
        return newElements;
    }


    public int size () {
        return this.size;
    }

    public boolean isEmpty () {
        return this.size () == 0;
    }

    public int get (int index) {
        validateIndex (index);
        return this.elements[index];
    }

    public boolean contains (int element) {
        for (int i = 0; i < this.size; i++) {
            if (this.elements[i] == element) {
                return true;
            }
        }
        return false;
    }
public void forEach(Consumer<Integer> consumer){
    for (int i = 0; i <this.size ; i++) {
        consumer.accept (this.elements[i]);
    }
}
    public void add (int index,int element) {
        validateIndex (index);
        int lastElement=this.elements[this.size-1];
        for (int i =this.size-1; i >index ; i--) {
            this.elements[i]=this.elements[i-1];
        }
        this.elements[index]=element;
        this.add (lastElement);
    }

    private void validateIndex (int index) {
        if (index < 0 || index >= this.size) {
            throw new IndexOutOfBoundsException ("Index " + index + " out of bounds " + "for size " + this.size);
        }
    }

    private int[] grow () {
        int[] newElements = new int[this.size * 2];
//        for (int i = 0; i < this.element.length; i++) {
//            newElements[i] = this.element[i];
//        }
        System.arraycopy (this.elements,0,newElements,0,this.elements.length);
        return newElements;
    }

}
