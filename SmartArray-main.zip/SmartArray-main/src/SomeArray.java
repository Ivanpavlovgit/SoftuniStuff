public class SomeArray {
}
