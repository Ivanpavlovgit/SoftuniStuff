public class LinkedListA {
    public static void main (String[] args) {

    }
}
