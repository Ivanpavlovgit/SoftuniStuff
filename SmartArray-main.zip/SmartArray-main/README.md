# SmartArray
Smart Array structure from Softuni excersice
