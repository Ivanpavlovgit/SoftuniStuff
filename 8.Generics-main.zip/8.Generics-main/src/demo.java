import java.util.ArrayList;
import java.util.List;

public class demo {
    public static void main (String[] args) {

        List<Integer> numbersInt = new ArrayList<> ();
        numbersInt.add (1);
        numbersInt.add (2);
        numbersInt.add (3);
        numbersInt.add (4);

        System.out.println (minInt (numbersInt));

        List<Double> numbersDouble = new ArrayList<> ();
        numbersDouble.add (4.4);
        numbersDouble.add (2.2);
        numbersDouble.add (3.3);
        numbersDouble.add (4.4);
        System.out.println (minDouble (numbersDouble));


        System.out.println (minT (numbersInt));
        System.out.println (minT (numbersDouble));

        List <String> texts=new ArrayList<> ();
        texts.add("Pesho");
        texts.add("Ivan");
        texts.add("GEORGI");
        System.out.println (minT (texts));

print (texts);
    }

    private static int minInt (List<Integer> numbersInt) {
        int minimum = Integer.MAX_VALUE;
        for (int num : numbersInt) {
            if (num < minimum) {
                minimum = num;
            }
        }
        return minimum;
    }

    private static double minDouble (List<Double> numbersInt) {
        double minimum = Double.MAX_VALUE;
        for (double num : numbersInt) {
            if (num < minimum) {
                minimum = num;
            }
        }
        return minimum;
    }

    private static <T extends Comparable<T>> T minT (List<T> numbersT) {
        T minimum = numbersT.get (0);
        for (int i = 1; i < numbersT.size (); i++) {
            if (minimum.compareTo (numbersT.get (i))>0) {
                minimum = numbersT.get (i);
            }
        }
        return minimum;
    }

    //        Scanner scanner = new Scanner (System.in);
//        int     a       = Integer.parseInt (scanner.nextLine ());
//        int     b       = Integer.parseInt (scanner.nextLine ());
//
//        int area = getArea (a,b);
//
//        int a1 = Integer.parseInt (scanner.nextLine ());
//        int a2 = Integer.parseInt (scanner.nextLine ());
//
//        int area1 = getArea (a1,a2);
//
//    }
//
    private static int getArea (int a,int b) {
        return a * b;
    }
    public static <T> void print (List<T> list){
        for (T element : list) {
            System.out.println (element);
        }
    }
}
