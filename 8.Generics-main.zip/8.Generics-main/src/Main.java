import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main (String[] args) {

        Scale<Integer> scale=new Scale<> (1,-1);
        System.out.println (scale.getHeavier ());

//        for (int num:create(Integer.class,12,1)
//             ) {
//            System.out.println (num);
//
//        }

//        JarOfPickles pickleJar = new JarOfPickles ();
//        pickleJar.add ("Pickle");
//
//        MyList<Integer> thisList=new MyList<Integer> ();
//thisList.add (4);
//thisList.add (4);
//thisList.add (4);
//        System.out.println (thisList.get (1));
//pickleJar.add (Pickle);
//        JarOfT<Integer> jar1=new JarOfT<> ();
//        JarOfT<String> jar2=new JarOfT<> ();
//        jar1.add (13);
//        jar2.add ("Pesho");
//
//
//        System.out.println (jar1.remove ());
//        System.out.println (jar2.remove ());


//        List<String> strings = new ArrayList<> ();
//        strings.add ("1");
//        strings.add ("2");
//        strings.add (String.valueOf (3));
//        String s = strings.get (0);
//        for (String string : strings) {
//            System.out.println (string.charAt (0));
//        }
//        for (Object string : strings) {
//            System.out.println (string);
//        }

//        String variable1=(String)strings.get(0);
//        String variable2=(String)strings.get(1);
//        String variable3=(String)strings.get(2);
//
//        System.out.println (strings.size ());
//
//        System.out.println (variable1.charAt(0));
//        System.out.println (variable2.charAt(0));
//        System.out.println (variable3.charAt(0));

//        String[]  elements = create (12,"element");
//        Integer[] numbers  = create (12,6);
//    }
//
//    public static <T> T[] create (int length,T element) {
//
//       T[] arr=(T[])new Object[length];
//
//        Object arr = Array.newInstance (element.getClass (),length);
//
//
//        return ((T[]) arr);
//
//    }
//
//    public static <T> T[] create (Class<T> clazz,int length,T item) {
//       return create (length,item);
//      //  return (T[]) Array.newInstance (clazz,length);
   }
}
