public class JarOfPickles extends Jar<String> {
}
