import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;
import java.util.function.Function;
import java.util.stream.Collectors;

public class SumNumbers {
    public static void main (String[] args) {
        //Write a program that reads one line of Integers separated by ", ". Print the count of the numbers and their sum.
        //Use a Function<String, Integer>
        Scanner scanner = new Scanner (System.in);
        int[] nums = Arrays.stream (scanner.nextLine ().split (", "))
                .mapToInt (Integer::parseInt)
                .toArray ();
        Function<int[], String> getCountStr =
                arr -> String.format ("Count = %d",arr.length);
        Function<int[], String> getSum =
                arr -> {
                    return "Sum = " + Arrays.stream (arr).sum ();
                };
        System.out.println (getSum.apply (nums));
        System.out.println (getCountStr.apply (nums));
//        Scanner scanner = new Scanner (System.in);
//
//        String[] inputNumbers = scanner.nextLine ().split (", ");
//
//        int sum = Arrays.stream (inputNumbers)
//                .mapToInt (n -> Integer.parseInt (n))
//                .sum ();
//
//        long count = Arrays.stream (inputNumbers)
//                .mapToInt (n -> Integer.parseInt (n))
//                .count ();
//
//        System.out.printf ("Count = %d%n",count);
//        System.out.printf("Sum = %d",sum);

    }
}
