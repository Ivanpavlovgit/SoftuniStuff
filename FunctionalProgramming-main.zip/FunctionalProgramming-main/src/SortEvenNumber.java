import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.Collectors;

public class SortEvenNumber {
    public static void main (String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] strings=scanner.nextLine ().split (", ");

        String output = Arrays.stream (strings)
                .mapToInt (e -> Integer.parseInt (e))
                .filter (num -> num % 2 == 0)
                .mapToObj (e -> String.valueOf (e))
                .collect (Collectors.joining (", "));
        System.out.println (output);

        output = Arrays.stream (strings)
                .mapToInt (e -> Integer.parseInt (e))
                .filter (num -> num % 2 == 0)
                .sorted ()
                //look at order or commands -> map after sort and before collect
                .mapToObj (e -> String.valueOf (e))
                .collect (Collectors.joining (", "));
        System.out.print (output);

//        Scanner scanner = new Scanner (System.in);
//
//        // int[] inputNumbers = Arrays.stream (scanner.nextLine ().split (", ")).mapToInt (Integer::parseInt).toArray ();
//        StringBuilder sb     = new StringBuilder ();
//        StringBuilder sbCool = new StringBuilder ();
//
//        List<Integer> numbers = Arrays.stream (scanner.nextLine ().split (", ")).map (Integer::parseInt).collect (Collectors.toList ());
//
//
//
//        numbers.removeIf (n -> n % 2 != 0);
//
//        for (Integer number : numbers) {
//            sb.append (number).append (", ");
//        }
//
//        System.out.println (sb.substring (0,sb.lastIndexOf (",")));
//
//        sb.replace (0,sb.length (),"");
//
//        numbers.sort (Integer::compareTo);
//
//        for (Integer number : numbers) {
//            sb.append (number).append (", ");
//        }
//
//        System.out.print (sb.substring (0,sb.lastIndexOf (",")));
    }
}
