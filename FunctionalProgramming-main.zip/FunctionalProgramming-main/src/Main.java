import java.awt.*;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public class Main {
    public static void main (String[] args) {
        Scanner       scanner = new Scanner (System.in);
        List<Integer> numbers=List.of (13,42,32,25);
//Suplier iska !OPTIONAL!
        Supplier<Optional<Integer>> supp=()->Optional.of (525);

        Integer maxNumber = numbers.stream ()
                .max (Integer::compareTo)
                .or (supp).get ();
        System.out.println (maxNumber);

//        Function<Integer, Integer> numToSquarex = x -> (x * x);
//        System.out.println (numToSquarex.apply (4));
//
//        Consumer<Double> doublePrinter = num -> System.out.printf ("%.2f",num);
//        doublePrinter.accept (Math.PI);
//        String[]                   strings = scanner.nextLine ().split (", ");
//        Function<Integer, Boolean> func    = num -> num % 2 == 0;
//        String output = Arrays.stream (strings)
//                .mapToInt (Integer::parseInt)
//                .filter (func::apply)
//                .mapToObj (String::valueOf)
//                .collect (Collectors.joining (", "));
//        System.out.println (output);
//        output = Arrays.stream (strings)
//                .mapToInt (Integer::parseInt)
//                .filter (func::apply)
//                .sorted ()
//                .mapToObj (String::valueOf)
//                .collect (Collectors.joining (", "));
//        System.out.println (output);
    }
}
