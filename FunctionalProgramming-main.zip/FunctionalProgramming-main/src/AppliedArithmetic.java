import org.w3c.dom.ls.LSOutput;

import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

public class AppliedArithmetic {
    public static void main (String[] args) {
        Scanner scanner = new Scanner (System.in);

        //"add" -> adds 1;
        // "multiply" -> multiplies by 2;
        // "subtract" -> subtracts 1;
        // "print" -> prints all numbers on a new line.
        // The input will end with an "end" command, after which you need to print the result.
        List<Integer> numbers = Arrays.stream (scanner.nextLine ().split ("\\s+")).map (Integer::parseInt).collect (Collectors.toList ());

//       // Function<List<Integer>, List<Integer>> addToListValues    = values -> values.stream ().map (v -> values.set (values.indexOf (v),v+1)).sorted ().collect (Collectors.toList ());
//        Function<List<Integer>, List<Integer>> increment    = values -> values.stream ().map (e->e+1).collect(Collectors.toList());
//       // Function<List<Integer>, List<Integer>> multiplyListValues = values -> values.stream ().map (v -> values.set (values.indexOf (v),v*2)).sorted ().collect (Collectors.toList ());
//        Function<List<Integer>, List<Integer>>  multiply    = values -> values.stream ().map (e->e*2).collect(Collectors.toList());
//      //  Function<List<Integer>, List<Integer>> subtractListValues = values -> values.stream ().map (v -> values.set (values.indexOf (v),v-1)).sorted ().collect (Collectors.toList ());
//        Function<List<Integer>, List<Integer>> subtract    = values -> values.stream ().map (e->e-1).collect(Collectors.toList());
        Consumer<List<Integer>> print     = values -> values.forEach (v -> System.out.printf ("%d ",v));

        Consumer<List<Integer>> multiply  = values -> values.stream ().map (v -> values.set (values.indexOf (v),v*2)).sorted ().collect (Collectors.toList ());
        Consumer<List<Integer>> increment  = values -> values.stream ().map (v -> values.set (values.indexOf (v),v+1)).sorted ().collect (Collectors.toList ());
        Consumer<List<Integer>> decrement  = values -> values.stream ().map (v -> values.set (values.indexOf (v),v-1)).sorted ().collect (Collectors.toList ());



//        int[]                  numbers   = Arrays.stream (scanner.nextLine ().split ("\\s+")).mapToInt (Integer::parseInt).toArray ();
//        Function<int[], int[]> increment = arr -> Arrays.stream (arr).map (e -> e += 1).toArray ();
//        Function<int[], int[]> multiply  = arr -> Arrays.stream (arr).map (e -> e *= 2).toArray ();
//        Function<int[], int[]> subtract  = arr -> Arrays.stream (arr).map (e -> e -= 1).toArray ();
//        Consumer<int[]>        print     = arr -> Arrays.stream (arr).forEach (e -> System.out.print (e + " "));

        String command = scanner.nextLine ();
        while (!command.equals ("end")) {
            switch (command) {
                case "add":
                    increment.accept (numbers);
                    break;
                case "multiply":
                    multiply.accept (numbers);
                    break;
                case "subtract":
                    decrement.accept (numbers);
                    break;
                case "print":
                    System.out.println ();
                    print.accept (numbers);
                    break;
            }

            command = scanner.nextLine ();
        }

        System.out.println ();
    }
}
