package com.softuni.model.entity;

public enum RoleNameEnum {
    ADMIN,
    USER;
}
